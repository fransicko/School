Michael Villafuerte

Q1: 8
Q2: The write up was good since it was our first time seeing and using these functions.
Q3: I would say it took me a little bit more than an hour.